<?php
/* Copyright (C) XEHub <https://www.xehub.io> */

/**
 * adminloggingModel class
 * model class of adminlogging module
 *
 * @author XEHub (developers@xpressengine.com)
 * @package /modules/adminlogging
 * @version 0.1
 */
class adminloggingModel extends adminlogging
{
	
}
/* End of file adminlogging.model.php */
/* Location: ./modules/adminlogging/adminlogging.model.php */
