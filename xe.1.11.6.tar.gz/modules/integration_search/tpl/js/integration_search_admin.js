/**
 * @file   modules/board/js/board_admin.js
 * @author XEHub (developers@xpressengine.com)
 * @brief  integration_search 모듈의 관리자용 javascript
 **/
